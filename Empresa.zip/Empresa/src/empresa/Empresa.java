package empresa;
import javax.swing.JOptionPane;

public class Empresa {

    public static void main(String[] args) {
       float sal[], media, soma, menor;
		int qtd, i, n, qtdmulher, pos, qtdhomem;
		String nome[], sexo[];		
				
		n=Integer.parseInt (JOptionPane.showInputDialog(null, 
			"Informe a quantidade de funcionários", 
			"Quantidade de funcionários", JOptionPane.INFORMATION_MESSAGE));
		nome = new String[n];
		sexo = new String[n];
		sal = new float[n];	
						
		for (i=0;i<n;i++){
			nome[i]=(JOptionPane.showInputDialog(null, 
				    "Informe o nome do funcionário - " + (i+1),
					"Nome do funcionário", JOptionPane.INFORMATION_MESSAGE));
			sexo[i]=(JOptionPane.showInputDialog(null, 
				    "Informe o sexo do funcionário - M ou F", 
					"Sexo do funcionário", JOptionPane.INFORMATION_MESSAGE));			
			sal[i] = Float.parseFloat (JOptionPane.showInputDialog (null, 
				    "Informe o salário do funcionário", 
					"Salário do funcionário", JOptionPane.INFORMATION_MESSAGE));		
		}
		
		//------------------------
		
		qtdmulher = 0; soma = 0;
		for (i=0;i<n;i++){
			if (sexo[i].toUpperCase().charAt(0)=='F'){
				soma=soma+sal[i];
				qtdmulher++;
			}
		} 
		media=soma/qtdmulher;
		JOptionPane.showMessageDialog (null, "A média salarial das mulheres é R$"
			    + media, "Média", JOptionPane.INFORMATION_MESSAGE);
		
		//------------------------

		pos=-1; menor=99999999;
		for (i=0;i<n;i++){
			if (sal[i]<menor){
				menor=sal[i];
				pos=i;
			}
		}
		JOptionPane.showMessageDialog (null, 
			   "O menor salário é R$" + sal[pos] 
			   + ", do funcionário " + nome[pos] 
			   + ", do sexo " + sexo[pos], 
			   "Menor salário", JOptionPane.INFORMATION_MESSAGE);

		//------------------------
	
	    qtdhomem = 0;
		for (i=0;i<n;i++){
			if (sal[i]>1000 && sexo[i].toUpperCase().charAt(0)=='M'){
				qtdhomem++;
			}
		}
		JOptionPane.showMessageDialog (null, 
			"A quantidade de homens que ganham mais de R$1000,00 é " 
			+ qtdhomem, "Homens", JOptionPane.INFORMATION_MESSAGE);
			
	}
		
}